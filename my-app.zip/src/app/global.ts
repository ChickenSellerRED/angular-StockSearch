export class Global {
  public static auto_options : object[]= [];
}
